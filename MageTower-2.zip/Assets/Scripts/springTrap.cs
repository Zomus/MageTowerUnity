﻿using UnityEngine;
using System.Collections;

public class springTrap : MonoBehaviour {

    public GameObject enemy;
	
	// Update is called once per frame
	void Update () {
	
	}
}
