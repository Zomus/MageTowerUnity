﻿using UnityEngine;
using System.Collections;

public class flowerMenu : MonoBehaviour {

    GameObject trapSection_1;
    GameObject trapSection_2;
    GameObject exitSection;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
