﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Main : MonoBehaviour {

    public static int wizardHp = 10;
    public static int wizardHpMax = 10;
    public static int finance = 0;
    public static int timer = 0;
    public static int stage = 1;
    public static int enemyLeft = 0;
    public static int tick = 0;

    public static bool stageStart = false;
    public static bool preSet = false;
    public static bool lv1pawn = false;
    public static bool lv2pawn = false;
    public static bool lv3pawn = false;

    bool shifter = false;

    public static List<Vector3> targetPoint = new List<Vector3>();
    public static int stageDefault = 0;
    public static int stageLimit = 0;

    public GameObject enemyPrefab;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {

        // Creates Enemy based on Tick.
        if (tick > 4 && enemyLeft > 0)
        {
            enemyCreator();
            tick = 0;
        }

        if (timer == 0 && stageStart == true)
        {
            winFunction();
        }
	}

    // This function creates enemy, switching between leftside and rightside.
    void enemyCreator()
    {
        if (shifter == false)
        {
            Instantiate(enemyPrefab, new Vector3(10,0.1f,0), Quaternion.identity);
            shifter = true;
        } else if (shifter == true)
        {
            Instantiate(enemyPrefab, new Vector3(-10,0.1f,0), Quaternion.identity);
            shifter = false;
        }
    }

    // This function handles what happens after portal time reaches 0.
    public void winFunction()
    {
        stageStart = false;
        stage++;
        preSet = false;
        string stageName = "sceneStage" + stage;
        Debug.Log("Next Level Ready");
        //Play some fancy animation.
        new WaitForSeconds(10);
        //Discard current stage and move to next stage.
        //Application.Loadlevel(stageName);
    }

    void stagePrep()
    {
        if (Main.stage == 1 && Main.preSet == false)
        {
            targetPoint.Add(new Vector3(-1.05f, 0.5f, 0f));
            targetPoint.Add(new Vector3(1.05f, 0.5f, 0f));
            targetPoint.Add(new Vector3(-1.05f, 4.2f, 0f));
            targetPoint.Add(new Vector3(1.05f, 4.2f, 0f));
            targetPoint.Add(new Vector3(-0.7f, 4.1f, 0f));
            targetPoint.Add(new Vector3(0.7f, 4.1f, 0f));
            stageDefault = 0;
            stageLimit = 4;
            Main.preSet = true;
        }
    }
}
