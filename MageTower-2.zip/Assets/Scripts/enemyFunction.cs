﻿using UnityEngine;
using System.Collections;

public class enemyFunction : MonoBehaviour {

    float mouseHoldSeconds = 0;
    float mouseDelaySeconds = 0.5f;
    public Rigidbody enemy;
    public Collider enemyCollider;
    float walkspeed = 0;
    int posA = 0;
    bool pickUp = false;
    bool attack = false;

    Ray ray;
    RaycastHit hit;

    private Vector3 screenPoint;
    private Vector3 offset;

    // Use this for initialization
    void Start () {
        walkspeed = 1.0f * Time.deltaTime;

        enemy = GetComponent<Rigidbody>();

        if (transform.position.x > 1)
        {
            posA = 1;
        }
	}
	
	// Update is called once per frame
	void Update () {

        if (pickUp == false && transform.position != Main.targetPoint[posA] && attack == false)
        {
            transform.position = Vector3.MoveTowards(transform.position, Main.targetPoint[posA], walkspeed);
            enemyCollider.attachedRigidbody.useGravity = false;
        }
        else if (pickUp == true)
        {
            posA = Main.stageDefault;
            enemyCollider.attachedRigidbody.useGravity = true;
            attack = false;
        }
        else if (pickUp == false && transform.position == Main.targetPoint[posA] && posA < Main.stageLimit)
        {
            posA += 2;
        }
        else if (pickUp == false && posA >= Main.stageLimit && transform.position == Main.targetPoint[posA])
        {
            enemyCollider.attachedRigidbody.useGravity = true;
            attack = true;
        }

	}

    // Targets point when mouse left click is held.
    void OnMouseDown()
    {
        screenPoint = Camera.main.WorldToScreenPoint(gameObject.transform.position);

        offset = gameObject.transform.position - Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z));
    }

    // Used to drag the object.
    void OnMouseDrag()
    {
        Vector3 curScreenPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z);

        Vector3 curPosition = Camera.main.ScreenToWorldPoint(curScreenPoint) + offset;
        transform.position = curPosition;
        pickUp = true;
    }

    // If dropped enemy fell, check the speed to kill enemy, or let it live.
    void OnCollisionEnter(Collision collision)
    {
        // Checks if enemy would die from falling, if it does, give money and kill it.
        if (collision.relativeVelocity.magnitude > 8)
        {
            Debug.Log("Killed");
            Main.finance += 10;
            Destroy(gameObject);
        }
        else
        {
            new WaitForSeconds(1);
            pickUp = false;
        }
    }
}
